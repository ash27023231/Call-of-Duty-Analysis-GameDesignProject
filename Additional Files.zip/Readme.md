In this project we do an exploratory data analysis on game data provided by Activision. We use various mining and analysis techniques to gather insightful patterns in the data.

We also use compare the performance of various classification algorithms to predict win/loss in games.